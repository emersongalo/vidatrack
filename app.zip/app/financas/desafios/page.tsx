"use client";

import Link from "next/link";
import { criarDesafio } from "./actions";
import { BotaoSalvarFormulario } from "@/components/BotaoSalvarFormulario";
import { CampoValorMonetario } from "@/components/CampoValorMonetario";
import { formatarMoeda } from "@/lib/financas/formatacao";
import { useSnapshotOffline } from "@/lib/offline/useSnapshot";

// Etapa 127: lista abre com o retrato local. A tela de detalhe de
// cada desafio (o grid de quadradinhos, /financas/desafios/[id]) e
// marcar um quadrado continuam precisando de internet — como
// mencionado antes, essa ação mexe em conta + progresso ao mesmo
// tempo, e prefiro fazer essa sincronização com cuidado numa etapa
// própria em vez de arriscar agora.
export default function DesafiosPage() {
  const { snapshot } = useSnapshotOffline();
  const desafios = snapshot?.financas.desafios ?? [];
  const contas = (snapshot?.financas.contas ?? []).filter((c: any) => c.tipo !== "investimento");

  return (
    <main className="min-h-screen p-6 md:p-12 max-w-md lg:max-w-3xl mx-auto">
      <Link href="/financas/mais" className="text-ink-400 text-sm hover:text-ink-100 transition">
        ← Mais
      </Link>
      <h1 className="text-2xl font-display font-semibold mt-4 mb-1">Desafios financeiros</h1>
      <p className="text-ink-400 text-sm mb-6">
        Tipo aquele desafio de guardar valores crescentes — só que aqui o app monta os quadradinhos e já
        tira o dinheiro certinho do seu saldo quando você marca.
      </p>

      {desafios.length > 0 && (
        <ul className="space-y-2 mb-8 lg:grid lg:grid-cols-2 lg:gap-3 lg:space-y-0">
          {desafios.map((d: any) => {
            const percentual = Math.min(100, Math.round((Number(d.valor_guardado) / Number(d.valor_alvo)) * 100));
            return (
              <li key={d.id}>
                <Link
                  href={`/financas/desafios/${d.id}`}
                  className="block bg-base-800 border border-base-600 rounded-xl2 shadow-lg shadow-black/20 p-4 hover:border-financa transition"
                >
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="font-medium">{d.nome}</span>
                    {d.concluido && <span className="text-xs text-habito font-medium">Concluído 🎉</span>}
                  </div>
                  <div className="h-2 bg-base-600 rounded-full overflow-hidden mb-2">
                    <div
                      className={`h-full rounded-full ${d.concluido ? "bg-habito" : "bg-financa"}`}
                      style={{ width: `${percentual}%` }}
                    />
                  </div>
                  <span className="text-sm font-mono text-ink-400">
                    {formatarMoeda(d.valor_guardado)} / {formatarMoeda(d.valor_alvo)}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}

      {contas.length === 0 ? (
        <p className="text-sm text-ink-400">Crie uma conta (não-investimento) antes de montar um desafio.</p>
      ) : (
        <div className="bg-base-800 border border-base-600 rounded-xl2 shadow-lg shadow-black/20 p-4">
          <p className="text-sm text-ink-400 mb-3">Novo desafio</p>
          <form action={criarDesafio} className="space-y-3">
            <input
              name="nome"
              type="text"
              placeholder="Nome (ex: Viagem de fim de ano)"
              required
              className="w-full bg-base-900 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
            />
            <div>
              <label className="block text-xs text-ink-400 mb-1.5">Quanto quer guardar no total</label>
              <CampoValorMonetario
                name="valorTotal"
                placeholder="Ex: 2.000,00"
                required
                className="w-full bg-base-900 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 font-mono focus:border-ink-100 outline-none transition"
              />
            </div>
            <div>
              <label className="block text-xs text-ink-400 mb-1.5">Em quanto tempo</label>
              <select
                name="prazoQuantidade"
                defaultValue="52"
                className="w-full bg-base-900 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
              >
                <option value="30">1 mês (30 quadrados, 1 por dia)</option>
                <option value="12">3 meses (12 quadrados, 1 por semana)</option>
                <option value="26">6 meses (26 quadrados, 1 por semana)</option>
                <option value="52">1 ano (52 quadrados, 1 por semana)</option>
                <option value="6">6 meses (6 quadrados, 1 por mês)</option>
              </select>
              <p className="text-xs text-ink-400 mt-1.5">
                O app calcula sozinho quanto cada quadrado vale pra bater esse total nesse prazo.
              </p>
            </div>
            <div>
              <label className="block text-xs text-ink-400 mb-1.5">Como distribuir</label>
              <select
                name="tipoProgressao"
                className="w-full bg-base-900 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
              >
                <option value="crescente">Crescente (começa pequeno, cresce a cada quadrado)</option>
                <option value="fixo">Fixo (mesmo valor sempre)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-ink-400 mb-1.5">De qual conta sai o dinheiro</label>
              <select
                name="contaOrigemId"
                required
                className="w-full bg-base-900 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
              >
                {contas.map((c: any) => (
                  <option key={c.id} value={c.id}>
                    {c.nome}
                  </option>
                ))}
              </select>
            </div>
            <BotaoSalvarFormulario>Criar desafio</BotaoSalvarFormulario>
          </form>
        </div>
      )}
    </main>
  );
}
