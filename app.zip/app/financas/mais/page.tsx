import Link from "next/link";
import { Tags, Repeat, BarChart3, ArrowUpDown, Download, Trash2, PiggyBank, Target, Upload, Users, TrendingUp, Grid3x3, Bot } from "lucide-react";
import { LinkVoltar } from "@/components/LinkVoltar";
import { IconeInstagram } from "@/components/IconeInstagram";

const ITENS = [
  { href: "/financas/assistente", Icone: Bot, titulo: "Assistente", texto: "Pergunte sobre seus gastos ou peça pra lançar algo por texto" },
  { href: "/financas/desafios", Icone: Grid3x3, titulo: "Desafios financeiros", texto: "Tipo o desafio dos 52 quadradinhos, dentro do app" },
  { href: "/financas/patrimonio", Icone: TrendingUp, titulo: "Patrimônio líquido", texto: "Evolução de tudo que você tem, mês a mês" },
  { href: "/financas/divisoes", Icone: Users, titulo: "Dividir despesas", texto: "Controle quem te deve e quem você deve" },
  { href: "/financas/importar", Icone: Upload, titulo: "Importar extrato", texto: "Sobe um arquivo OFX ou CSV do seu banco" },
  { href: "/financas/metas", Icone: Target, titulo: "Metas de economia", texto: "Guarde dinheiro pra um objetivo específico" },
  { href: "/financas/investir", Icone: PiggyBank, titulo: "Guardar em investimento", texto: "Separe dinheiro do seu saldo pra investimento" },
  { href: "/financas/categorias", Icone: Tags, titulo: "Categorias", texto: "Organize receitas e despesas por tipo" },
  { href: "/financas/recorrentes", Icone: Repeat, titulo: "Recorrentes", texto: "Contas e receitas que se repetem todo mês" },
  { href: "/financas/analise", Icone: BarChart3, titulo: "Análise", texto: "Mapa de gastos e comparação com o mês passado" },
  { href: "/financas/personalizar", Icone: ArrowUpDown, titulo: "Personalizar ordem", texto: "Reorganize os blocos da tela inicial" },
  { href: "/financas/exportar", Icone: Download, titulo: "Exportar CSV", texto: "Baixe seus lançamentos em planilha" },
  { href: "/financas/contas/lixeira", Icone: Trash2, titulo: "Lixeira de contas", texto: "Contas arquivadas — restaure ou exclua de vez" },
];

export default function MaisFinancasPage() {
  return (
    <main className="min-h-screen p-6 pb-24 max-w-2xl lg:max-w-4xl mx-auto">
      <LinkVoltar href="/financas" texto="Finanças" />
      <h1 className="text-2xl font-display font-semibold mt-4 mb-6">Mais</h1>

      <ul className="space-y-2 lg:grid lg:grid-cols-2 lg:gap-3 lg:space-y-0">
        {ITENS.map((item) => (
          <li key={item.href}>
            <Link
              href={item.href}
              className="flex items-center gap-3 bg-base-800 border border-base-600 rounded-xl2 p-4 hover:border-financa transition"
            >
              <span className="w-9 h-9 rounded-lg bg-financa/15 flex items-center justify-center text-financa shrink-0">
                <item.Icone size={18} strokeWidth={2} />
              </span>
              <div className="flex-1 min-w-0">
                <p className="font-medium">{item.titulo}</p>
                <p className="text-xs text-ink-400 mt-0.5">{item.texto}</p>
              </div>
              <span className="text-ink-400 shrink-0">→</span>
            </Link>
          </li>
        ))}
      </ul>

      {/* Etapa 140 */}
      <div className="flex flex-col items-center gap-3 mt-10 pt-6 border-t border-base-600">
        <a
          href="https://instagram.com/vidatrack_"
          target="_blank"
          rel="noopener noreferrer"
          className="w-11 h-11 rounded-full border border-base-600 flex items-center justify-center text-ink-400 hover:text-financa hover:border-financa transition"
          aria-label="VidaTrack no Instagram"
        >
          <IconeInstagram size={20} />
        </a>
        <p className="text-xs text-ink-400">@vidatrack_ no Instagram</p>
      </div>
    </main>
  );
}
