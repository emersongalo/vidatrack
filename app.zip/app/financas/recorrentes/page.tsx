"use client";

import { Suspense, useTransition } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { criarRecorrencia, alternarAtivaRecorrencia, removerRecorrencia } from "./actions";
import { formatarMoeda } from "@/lib/financas/formatacao";
import { BotaoComConfirmacao } from "@/components/BotaoComConfirmacao";
import { BotaoSalvarFormulario } from "@/components/BotaoSalvarFormulario";
import { useSnapshotOffline } from "@/lib/offline/useSnapshot";

// Etapa 129
export default function RecorrentesPage() {
  return (
    <Suspense fallback={null}>
      <RecorrentesConteudo />
    </Suspense>
  );
}

function RecorrentesConteudo() {
  const searchParams = useSearchParams();
  const erro = searchParams.get("erro");
  const { snapshot, recarregar } = useSnapshotOffline();
  const [, iniciarTransicao] = useTransition();

  const recorrencias = [...(snapshot?.financas.recorrencias ?? [])].sort((a: any, b: any) => a.dia_mes - b.dia_mes);
  const contas = snapshot?.financas.contas ?? [];
  const categorias = (snapshot?.financas.categorias ?? []).filter((c: any) => c.dono_id === snapshot?.perfil.id);
  const mapaContas = new Map(contas.map((c: any) => [c.id, c.nome]));

  function alternarAtiva(id: string) {
    iniciarTransicao(async () => {
      await alternarAtivaRecorrencia(id);
      recarregar();
    });
  }

  return (
    <main className="min-h-screen p-6 md:p-12 max-w-md lg:max-w-3xl mx-auto">
      <Link href="/financas" className="text-ink-400 text-sm hover:text-ink-100 transition">
        ← Finanças
      </Link>
      <h1 className="text-2xl font-display font-semibold mt-4 mb-1">Recorrentes</h1>
      <p className="text-ink-400 text-sm mb-6">Lançamentos que se repetem todo mês, como aluguel ou salário.</p>

      {erro && (
        <p className="mb-4 text-sm text-red-400 bg-red-400/10 border border-red-400/30 rounded-lg px-3 py-2">
          {decodeURIComponent(erro)}
        </p>
      )}

      {recorrencias.length > 0 && (
        <ul className="space-y-2 mb-8 lg:grid lg:grid-cols-2 lg:gap-3 lg:space-y-0">
          {recorrencias.map((r: any) => (
            <li
              key={r.id}
              className={`flex items-center justify-between bg-base-800 border border-base-600 rounded-lg p-3 ${!r.ativo ? "opacity-50" : ""}`}
            >
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{r.descricao || mapaContas.get(r.conta_id)}</p>
                <p className="text-xs text-ink-400">
                  Todo dia {r.dia_mes} · {mapaContas.get(r.conta_id)}
                  {r.data_fim && <> · até {new Date(r.data_fim + "T00:00:00").toLocaleDateString("pt-BR")}</>}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className={`font-mono text-sm ${r.tipo === "receita" ? "text-habito" : "text-red-400"}`}>
                  {r.tipo === "receita" ? "+" : "-"}
                  {formatarMoeda(r.valor)}
                </span>
                <button onClick={() => alternarAtiva(r.id)} className="text-ink-400 hover:text-ink-100 transition text-xs">
                  {r.ativo ? "Pausar" : "Ativar"}
                </button>
                <BotaoComConfirmacao acao={removerRecorrencia.bind(null, r.id)} textoBotao="Remover" aoConcluir={recarregar} />
              </div>
            </li>
          ))}
        </ul>
      )}

      {snapshot !== undefined && contas.length === 0 ? (
        <p className="text-ink-400 text-sm">Crie uma conta primeiro para adicionar recorrências.</p>
      ) : (
        <>
          <p className="text-sm text-ink-400 mb-3">Nova recorrência</p>
          <form action={criarRecorrencia} className="space-y-3">
            <select
              name="tipo"
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
            >
              <option value="despesa">Despesa</option>
              <option value="receita">Receita</option>
            </select>
            <input
              name="valor"
              type="text"
              inputMode="decimal"
              required
              placeholder="Valor (ex: 1500,00)"
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition font-mono"
            />
            <select
              name="contaId"
              required
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
            >
              {contas.map((c: any) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
            <select
              name="categoriaId"
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
            >
              <option value="">Sem categoria</option>
              {categorias.map((c: any) => (
                <option key={c.id} value={c.id}>
                  {c.icone ? `${c.icone} ` : ""}
                  {c.nome}
                </option>
              ))}
            </select>
            <div>
              <label htmlFor="diaMes" className="block text-sm text-ink-400 mb-1">
                Todo dia (1 a 28)
              </label>
              <input
                id="diaMes"
                name="diaMes"
                type="number"
                min={1}
                max={28}
                defaultValue={5}
                className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition font-mono"
              />
            </div>
            <div>
              <label htmlFor="dataFim" className="block text-sm text-ink-400 mb-1">
                Até quando? (opcional — deixe em branco pra "sempre")
              </label>
              <input
                id="dataFim"
                name="dataFim"
                type="date"
                className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
              />
            </div>
            <input
              name="descricao"
              type="text"
              placeholder="Descrição (ex: Aluguel, Salário)"
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-ink-100 focus:border-ink-100 outline-none transition"
            />
            <BotaoSalvarFormulario>Criar recorrência</BotaoSalvarFormulario>
          </form>
          <p className="text-xs text-ink-400 mt-3">
            O lançamento do mês é criado automaticamente na primeira vez que você abrir o app naquele mês, a
            partir do dia escolhido — não é um agendador rodando sozinho no fundo.
          </p>
        </>
      )}
    </main>
  );
}
