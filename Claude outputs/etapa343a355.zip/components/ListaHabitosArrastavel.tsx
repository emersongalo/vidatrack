"use client";

import Link from "next/link";
import { Pencil, Share2, Archive } from "lucide-react";
import { ListaArrastavel } from "@/components/ListaArrastavel";
import { MenuAcoes, ItemMenuAcoes } from "@/components/MenuAcoes";
import { classeCor, classeFundoSuave } from "@/lib/agenda/estilo";
import { IconeHabito } from "@/components/IconeHabito";
import { arquivarHabito, reordenarHabitos, restaurarHabito } from "@/app/habitos/actions";
import { comDesfazer } from "@/lib/app/desfazer";
import { chamarOuGuardar } from "@/lib/local/acaoOffline";
import { atualizarSnapshotEmTodasAsTelas } from "@/lib/offline/useSnapshot";

const RÓTULOS_FREQUENCIA: Record<string, string> = {
  diaria: "Todos os dias",
  dias_semana: "Dias específicos",
  semanal: "Algumas vezes por semana",
};

type Habito = {
  id: string;
  nome: string;
  cor: string;
  icone: string;
  frequencia: string;
  categorias_produtividade: { nome: string } | null;
  streakAtual?: number;
  melhorStreak?: number;
  eh_negativo?: boolean;
  ultimos7?: { dia: string; estado: "feito" | "falhou" | "folga" }[];
};

export function ListaHabitosArrastavel({ habitos, aoMudar }: { habitos: Habito[]; aoMudar?: () => void }) {
  return (
    <ListaArrastavel
      itens={habitos}
      // Etapa 353 — sem internet também
      aoReordenar={(ids: string[]) =>
        chamarOuGuardar(() => reordenarHabitos(ids), {
          acao: "reordenarHabitos",
          args: [ids],
          patches: [{ colecao: "habitos", op: "ordenar", ids }],
          rotulo: "Ordem dos hábitos",
        }).then(() => {})
      }
      classeLista="bg-base-800 border border-base-600 rounded-3xl overflow-hidden divide-y divide-base-600"
      renderItem={(habito, arrastando) => (
        // Etapa 227 — linha no estilo da lista de Contas: ícone redondo, nome e
        // frequência, e a sequência 🔥 à direita (no lugar do saldo)
        <div className={`flex items-center gap-3 px-4 py-3.5 transition ${arrastando ? "opacity-50" : ""}`}>
          <span className="text-ink-400 text-sm select-none hidden md:block" aria-hidden>
            ⠿
          </span>
          <Link href={`/habitos/${habito.id}`} className="flex items-center gap-3 flex-1 min-w-0">
            <span
              className={`w-12 h-12 rounded-full flex items-center justify-center text-xl shrink-0 ${classeFundoSuave(habito.cor)}`}
            >
              <IconeHabito icone={habito.icone} tamanho={22} />
            </span>
            <span className="flex-1 min-w-0">
              <span className="block text-lg font-medium truncate">{habito.nome}</span>
              <span className="block text-sm text-ink-400 truncate">
                {RÓTULOS_FREQUENCIA[habito.frequencia] ?? "Personalizado"}
                {habito.categorias_produtividade?.nome && ` · ${habito.categorias_produtividade.nome}`}
              </span>
              {/* Etapa 230 — semana na linha */}
              {habito.ultimos7 && (
                <span className="flex items-center gap-1 mt-1.5" aria-label="Últimos 7 dias">
                  {habito.ultimos7.map((d) => (
                    <span
                      key={d.dia}
                      className={`w-2.5 h-2.5 rounded-full ${
                        d.estado === "feito" ? classeCor(habito.cor) : d.estado === "falhou" ? "bg-base-600" : "border border-base-600"
                      }`}
                    />
                  ))}
                </span>
              )}
            </span>
            <span className="text-right shrink-0">
              {habito.eh_negativo ? (
                <>
                  <span className="block text-lg font-semibold">🛡️ {habito.streakAtual ?? 0}</span>
                  <span className="block text-xs text-ink-400">dias limpo</span>
                </>
              ) : (
                <>
                  <span className={`block text-lg font-semibold ${(habito.streakAtual ?? 0) > 0 ? "text-financa" : "text-ink-400"}`}>
                    🔥 {habito.streakAtual ?? 0}
                  </span>
                  <span className="block text-xs text-ink-400">recorde {habito.melhorStreak ?? 0}</span>
                </>
              )}
            </span>
          </Link>
          <MenuAcoes>
            {(fecharMenu) => (
              <>
                <ItemMenuAcoes href={`/habitos/${habito.id}/editar`}>
                  <Pencil size={15} strokeWidth={2} /> Editar
                </ItemMenuAcoes>
                <ItemMenuAcoes href={`/habitos/${habito.id}/compartilhar`}>
                  <Share2 size={15} strokeWidth={2} /> Compartilhar
                </ItemMenuAcoes>
                <div className="my-1 border-t border-base-600" />
                {/* Etapa 276 — arquiva na hora, com "Desfazer" */}
                <button
                  type="button"
                  onClick={async () => {
                    fecharMenu();
                    // Etapa 350 — sem internet: arquiva no aparelho e sobe depois
                    const copia = { ...(habito as any) };
                    await chamarOuGuardar(() => arquivarHabito(habito.id), {
                      acao: "arquivarHabito",
                      args: [habito.id],
                      patches: [{ colecao: "habitos", op: "remover", id: habito.id }],
                      rotulo: `Arquivar "${habito.nome}"`,
                    });
                    aoMudar?.();
                    void atualizarSnapshotEmTodasAsTelas();
                    comDesfazer({
                      texto: `"${habito.nome}" arquivado`,
                      desfazer: () =>
                        chamarOuGuardar(() => restaurarHabito(habito.id), {
                          acao: "restaurarHabito",
                          args: [habito.id],
                          patches: [{ colecao: "habitos", op: "upsert", id: habito.id, valores: copia }],
                          rotulo: `Desarquivar "${habito.nome}"`,
                        }),
                      aoTerminar: () => {
                        aoMudar?.();
                        void atualizarSnapshotEmTodasAsTelas();
                      },
                    });
                  }}
                  className="flex items-center gap-2.5 w-full px-3.5 py-2 text-sm text-left text-ink-100 hover:bg-base-700 transition"
                >
                  <Archive size={15} strokeWidth={2} /> Arquivar
                </button>
              </>
            )}
          </MenuAcoes>
        </div>
      )}
    />
  );
}
