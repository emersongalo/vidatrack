"use client";

import { Suspense, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { enviarSemInternet } from "@/lib/local/acaoOffline";
import { pedidoAtualizarConta } from "@/lib/local/financasCadastros";
import Link from "next/link";
import { atualizarConta } from "@/app/financas/actions";
import { BANCOS } from "@/lib/financas/bancos";
import { SeletorTipoConta } from "@/components/SeletorTipoConta";
import { BotaoSalvarFormulario } from "@/components/BotaoSalvarFormulario";
import { useSnapshotOffline } from "@/lib/offline/useSnapshot";
import { CarregandoTela } from "@/components/Esqueleto";

// Etapa 128
export default function EditarContaPage() {
  return (
    <Suspense fallback={null}>
      <EditarContaConteudo />
    </Suspense>
  );
}

function EditarContaConteudo() {
  const params = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const erro = searchParams.get("erro");
  const { snapshot } = useSnapshotOffline();
  const router = useRouter();
  const [erroOffline, setErroOffline] = useState<string | null>(null);

  if (snapshot === undefined) return <CarregandoTela comTopo={false} linhas={5} />;

  const conta = (snapshot?.financas.contas ?? []).find((c: any) => c.id === params.id);

  if (!conta) {
    return (
      <main className="min-h-screen p-6 md:p-12 pagina-form">
        <Link href="/financas/contas" className="text-ink-400 text-base hover:text-ink-100 transition">
          ← Contas
        </Link>
        <p className="text-ink-400 text-sm mt-6">
          Não encontrei essa conta no que está salvo no aparelho. Se você criou ela há pouco tempo, conecte à
          internet uma vez pra atualizar.
        </p>
      </main>
    );
  }

  return (
    <main className="min-h-screen p-6 md:p-12 pagina-form">
      <Link href="/financas/contas" className="text-ink-400 text-base hover:text-ink-100 transition">
        ← Contas
      </Link>
      <h1 className="text-3xl font-display font-bold mt-4 mb-6">Editar conta</h1>

      {erro && (
        <p className="mb-4 text-sm text-red-400 bg-red-400/10 border border-red-400/30 rounded-lg px-3 py-2">
          {decodeURIComponent(erro)}
        </p>
      )}

      {erroOffline && (
        <p className="mb-4 text-sm text-red-400 bg-red-400/10 border border-red-400/30 rounded-lg px-3 py-2">{erroOffline}</p>
      )}

      {/* Etapa 352 — sem internet: salva no aparelho e sobe depois */}
      <form
        action={atualizarConta.bind(null, conta.id)}
        onSubmit={(e) => enviarSemInternet(e, (fd) => pedidoAtualizarConta(conta.id, fd), () => router.push("/financas/contas"), setErroOffline)}
      >
        <div className="form-colunas">
        <div className="form-coluna">
        <input
          name="nome"
          type="text"
          required
          defaultValue={conta.nome}
          className="w-full bg-base-800 border border-base-600 rounded-2xl px-4 py-3.5 text-ink-100 focus:border-ink-100 outline-none transition"
        />
        <SeletorTipoConta
          tipoInicial={conta.tipo}
          diaFechamentoInicial={conta.dia_fechamento}
          diaVencimentoInicial={conta.dia_vencimento}
          limiteInicial={(conta as any).limite ?? null}
        />
        </div>
        <div className="form-coluna">
        <div>
          <label className="block text-xs text-ink-400 mb-1.5">Banco (pra mostrar o selo certo)</label>
          <select
            name="banco"
            defaultValue={conta.banco ?? "outro"}
            className="w-full bg-base-800 border border-base-600 rounded-2xl px-4 py-3.5 text-ink-100 focus:border-ink-100 outline-none transition"
          >
            {BANCOS.map((b) => (
              <option key={b.id} value={b.id}>
                {b.nome}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-ink-400 mb-1.5">Saldo inicial</label>
          <input
            name="saldoInicial"
            type="text"
            inputMode="decimal"
            defaultValue={String(conta.saldo_inicial).replace(".", ",")}
            className="w-full bg-base-800 border border-base-600 rounded-2xl px-4 py-3.5 text-ink-100 focus:border-ink-100 outline-none transition font-mono"
          />
        </div>
        </div>
        </div>
        <div className="form-rodape">
          <BotaoSalvarFormulario>Salvar alterações</BotaoSalvarFormulario>
        </div>
      </form>
    </main>
  );
}
