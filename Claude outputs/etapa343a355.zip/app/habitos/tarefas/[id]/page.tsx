"use client";

import { Suspense, useState, useTransition } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import { IconeHabito } from "@/components/IconeHabito";
import { arquivarTarefa, alternarConclusaoTarefaUnica, restaurarTarefa } from "../actions";
import { chamarOuGuardar } from "@/lib/local/acaoOffline";
import { useRouter } from "next/navigation";
import { comDesfazer } from "@/lib/app/desfazer";
import { atualizarSnapshotEmTodasAsTelas } from "@/lib/offline/useSnapshot";
import { CheckboxSubtarefa } from "@/components/CheckboxSubtarefa";
import { PainelCompartilhamentoCliente } from "@/components/PainelCompartilhamentoCliente";
import { useSnapshotOffline } from "@/lib/offline/useSnapshot";
import { descreverRepeticao, tarefaAtrasada, PRIORIDADES } from "@/lib/agenda/recorrencia";
import { hojeISO } from "@/lib/habitos/streak";
import { CarregandoTela } from "@/components/Esqueleto";
import { FocoTarefa } from "@/components/FocoTarefa";

// Etapa 134
export default function DetalheTarefaPage() {
  return (
    <Suspense fallback={null}>
      <DetalheTarefaConteudo />
    </Suspense>
  );
}

function DetalheTarefaConteudo() {
  const params = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const { snapshot, recarregar } = useSnapshotOffline();
  const router = useRouter();
  const [, iniciarTransicao] = useTransition();
  // Precisa vir antes de qualquer "return" condicional (regra dos hooks
  // do React) — por isso o valor de partida é um objeto vazio, não os
  // dados da tarefa (que a essa altura ainda não sabemos se existe).
  const [subtarefasSobrepostas, setSubtarefasSobrepostas] = useState<Record<string, boolean>>({});
  // Etapa 275 — modo foco
  const [focando, setFocando] = useState(false);

  if (snapshot === undefined) return <CarregandoTela linhas={3} />;

  const tarefa = (snapshot?.tarefas ?? []).find((t: any) => t.id === params.id);

  if (!tarefa) {
    return (
      <main className="pagina-form px-6 md:px-12 pt-6">
        <Link href="/tarefas" className="text-ink-400 text-base hover:text-ink-100 transition">
          ← Tarefas
        </Link>
        <p className="text-ink-400 text-sm mt-6">
          Não encontrei essa tarefa no que está salvo no aparelho. Se ela foi criada há pouco tempo, conecte à
          internet uma vez pra atualizar.
        </p>
      </main>
    );
  }

  const subtarefas = ((tarefa.subtarefas as { id: string; texto: string; feita: boolean }[]) ?? []).map((s) =>
    s.id in subtarefasSobrepostas ? { ...s, feita: subtarefasSobrepostas[s.id] } : s
  );

  function alternarSubtarefaLocal(id: string, feitaAtual: boolean) {
    setSubtarefasSobrepostas((atual) => ({ ...atual, [id]: !feitaAtual }));
  }

  function alternarConcluida() {
    iniciarTransicao(async () => {
      // Etapa 350 — sem internet: marca no aparelho e sobe depois
      const r = await chamarOuGuardar(() => alternarConclusaoTarefaUnica(tarefa.id), {
        acao: "alternarConclusaoTarefaUnica",
        args: [tarefa.id],
        patches: [{ colecao: "tarefas", op: "mesclar", id: tarefa.id, valores: { concluida: !tarefa.concluida } }],
        rotulo: `Concluir "${tarefa.titulo}"`,
      });
      if (r !== "fila") recarregar();
    });
  }

  return (
    <main className="pagina-form px-6 md:px-12 pt-2">
      <div className="flex items-center justify-between mb-6">
        <Link href="/tarefas" className="text-ink-400 text-base hover:text-ink-100 transition">
          ← Tarefas
        </Link>
        <div className="flex items-center gap-4">
          <Link href={`/tarefas/${tarefa.id}/editar`} className="text-ink-400 text-base hover:text-ink-100 transition">
            Editar
          </Link>
          {/* Etapa 276 — arquiva e volta pra lista, com "Desfazer" */}
          <button
            type="button"
            onClick={() => {
              // Etapa 350 — sem internet também: arquiva no aparelho e sobe depois
              const copia = { ...(tarefa as any) };
              comDesfazer({
                texto: "Tarefa arquivada",
                desfazer: () =>
                  chamarOuGuardar(() => restaurarTarefa(tarefa.id), {
                    acao: "restaurarTarefa",
                    args: [tarefa.id],
                    patches: [{ colecao: "tarefas", op: "upsert", id: tarefa.id, valores: copia }],
                    rotulo: `Desarquivar "${tarefa.titulo}"`,
                  }),
                aoTerminar: () => void atualizarSnapshotEmTodasAsTelas(),
              });
              void chamarOuGuardar(() => arquivarTarefa(tarefa.id), {
                acao: "arquivarTarefa",
                args: [tarefa.id],
                patches: [{ colecao: "tarefas", op: "remover", id: tarefa.id }],
                rotulo: `Arquivar "${tarefa.titulo}"`,
              })
                .then((r) => {
                  if (r === "fila") router.push("/tarefas");
                })
                .catch(() => {})
                .finally(() => void atualizarSnapshotEmTodasAsTelas());
            }}
            className="text-ink-400 text-sm hover:text-red-400 transition"
          >
            Arquivar
          </button>
        </div>
      </div>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-nota/15 flex items-center justify-center text-2xl shrink-0">
          <IconeHabito icone={tarefa.icone} tamanho={22} />
        </div>
        <div>
          <h1 className={`text-xl font-display font-semibold ${tarefa.concluida ? "line-through text-ink-400" : ""}`}>
            {tarefa.titulo}
          </h1>
          <p className="text-xs text-ink-400 flex items-center gap-2 flex-wrap">
            <span className={tarefaAtrasada(tarefa, hojeISO()) ? "text-red-400" : ""}>
              {tarefa.repetir === "nenhuma" ? "" : "↻ "}
              {descreverRepeticao(tarefa)}
              {tarefaAtrasada(tarefa, hojeISO()) && " · atrasada"}
            </span>
            {!!tarefa.prioridade && tarefa.prioridade > 0 && (
              <span className={`flex items-center gap-1 ${PRIORIDADES[tarefa.prioridade].classe}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${PRIORIDADES[tarefa.prioridade].fundo}`} />
                Prioridade {PRIORIDADES[tarefa.prioridade].rotulo.toLowerCase()}
              </span>
            )}
          </p>
        </div>
      </div>

      {tarefa.financa_valor && (
        <div className="flex items-center gap-3 bg-financa/10 border border-financa/30 rounded-xl2 p-3 mb-4 text-sm">
          <span className="text-lg">💰</span>
          <p className="flex-1 min-w-0">
            Ao concluir, lança {tarefa.financa_tipo === "receita" ? "uma receita" : "uma despesa"} de{" "}
            <span className="font-mono font-medium">
              R$ {Number(tarefa.financa_valor).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </span>
            {(() => {
              const conta = (snapshot?.financas.contas ?? []).find((c: any) => c.id === tarefa.financa_conta_id);
              return conta ? <> em <span className="font-medium">{conta.nome}</span></> : null;
            })()}
            .
          </p>
        </div>
      )}

      {tarefa.repetir === "nenhuma" && (
        <button
          onClick={alternarConcluida}
          className={`w-full rounded-2xl py-3.5 text-sm font-medium border transition mb-6 ${
            tarefa.concluida ? "border-nota text-nota bg-nota-soft" : "bg-ink-100 text-base-900 border-ink-100"
          }`}
        >
          {tarefa.concluida ? "Marcada como concluída ✓" : "Marcar como concluída"}
        </button>
      )}

      {/* Etapa 275 — modo foco */}
      {!(tarefa.repetir === "nenhuma" && tarefa.concluida) && (
        <button
          type="button"
          onClick={() => setFocando(true)}
          className="w-full flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-medium border border-nota/40 text-nota bg-nota/10 hover:bg-nota/15 transition mb-6 active:scale-[0.98]"
        >
          🎯 Focar nesta tarefa
        </button>
      )}
      {focando && (
        <FocoTarefa
          tarefa={{ ...tarefa, subtarefas }}
          aoFechar={() => {
            setFocando(false);
            recarregar();
          }}
        />
      )}

      {tarefa.observacoes && (
        <div className="mb-6">
          <p className="text-sm text-ink-400 mb-2">Observações</p>
          <p className="bg-base-800 border border-base-600 rounded-xl2 p-4 text-sm whitespace-pre-wrap">
            {tarefa.observacoes}
          </p>
        </div>
      )}

      {subtarefas.length > 0 && (
        <div className="mb-6">
          <p className="text-sm text-ink-400 mb-3">
            Checklist · {subtarefas.filter((s) => s.feita).length}/{subtarefas.length}
          </p>
          <div className="space-y-2">
            {subtarefas.map((s) => (
              <CheckboxSubtarefa
                key={s.id}
                tarefaId={tarefa.id}
                subtarefaId={s.id}
                texto={s.texto}
                feita={s.feita}
                aoAlternarLocal={() => alternarSubtarefaLocal(s.id, s.feita)}
              />
            ))}
          </div>
        </div>
      )}

      <div className="pt-6 border-t border-base-600">
        <h2 className="text-lg font-semibold mb-3">Compartilhar</h2>
        <PainelCompartilhamentoCliente
          tipoItem="tarefa"
          itemId={tarefa.id}
          caminhoRetorno={`/tarefas/${tarefa.id}`}
          erroInicial={searchParams.get("erro")}
        />
      </div>
    </main>
  );
}
