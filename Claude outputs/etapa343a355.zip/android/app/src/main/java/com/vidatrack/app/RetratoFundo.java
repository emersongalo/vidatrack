package com.vidatrack.app;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.vidatrack.app.widget.Rede;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Etapa 349 — mantém os dados do app em dia MESMO SEM ABRIR O APP.
 *
 * De tempos em tempos (e a cada lembrete que chega), o próprio Android
 * baixa o "retrato" (/api/offline/baixar-tudo) com a mesma sessão da
 * WebView e guarda num arquivo privado do app. Quando o app abre —
 * principalmente sem internet — ele compara com o que já tinha e usa o
 * mais novo. Assim, ficar dias sem abrir e depois abrir sem sinal mostra
 * os dados de poucas horas atrás, não os de dias atrás.
 *
 * De quebra, cada chamada renova os cookies da sessão (Rede grava de
 * volta), então o login não expira por falta de uso.
 */
public final class RetratoFundo {

    private static final String ARQUIVO = "retrato-fundo.json";
    private static final String PREFS = "retrato_fundo";
    private static final String CHAVE_ULTIMA = "ultima";
    private static final String TRABALHO = "vt-retrato-fundo";

    private RetratoFundo() {}

    /**
     * Baixa agora (se a última vez foi há mais de `intervaloMinimoMs`).
     * Roda na thread de quem chamou — nunca chamar na thread principal.
     * Devolve false só quando vale a pena tentar de novo (rede/servidor).
     */
    public static boolean baixarAgora(Context contexto, long intervaloMinimoMs) {
        SharedPreferences prefs = contexto.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long agora = System.currentTimeMillis();
        if (agora - prefs.getLong(CHAVE_ULTIMA, 0) < intervaloMinimoMs) return true;
        try {
            Rede.Resposta resposta = Rede.requisitar("GET", "/api/offline/baixar-tudo", null);
            // 3xx/401 = sessão caiu (precisa entrar no app de novo): não insiste
            if (resposta.status != 200) return resposta.status < 500;
            String corpo = resposta.corpo == null ? "" : resposta.corpo.trim();
            if (!corpo.startsWith("{")) return true;

            File destino = new File(contexto.getFilesDir(), ARQUIVO);
            File temporario = new File(contexto.getFilesDir(), ARQUIVO + ".tmp");
            FileOutputStream saida = new FileOutputStream(temporario);
            saida.write(corpo.getBytes(StandardCharsets.UTF_8));
            saida.getFD().sync();
            saida.close();
            if (!temporario.renameTo(destino)) {
                destino.delete();
                temporario.renameTo(destino);
            }
            prefs.edit().putLong(CHAVE_ULTIMA, agora).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** O retrato guardado pelo Android (ou null se não tiver). */
    public static String ler(Context contexto) {
        File arquivo = new File(contexto.getFilesDir(), ARQUIVO);
        if (!arquivo.exists()) return null;
        try {
            FileInputStream entrada = new FileInputStream(arquivo);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bloco = new byte[8192];
            int lidos;
            while ((lidos = entrada.read(bloco)) != -1) buffer.write(bloco, 0, lidos);
            entrada.close();
            return buffer.toString("UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    /** O app já pegou o retrato: apaga o arquivo (não guarda cópia à toa). */
    public static void apagar(Context contexto) {
        new File(contexto.getFilesDir(), ARQUIVO).delete();
    }

    /** Agenda a atualização a cada ~4 horas, só quando tiver internet. */
    public static void agendar(Context contexto) {
        try {
            Constraints regras = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
            PeriodicWorkRequest pedido = new PeriodicWorkRequest.Builder(RetratoWorker.class, 4, TimeUnit.HOURS)
                .setConstraints(regras)
                .build();
            WorkManager.getInstance(contexto.getApplicationContext())
                .enqueueUniquePeriodicWork(TRABALHO, ExistingPeriodicWorkPolicy.KEEP, pedido);
        } catch (Exception e) {
            // sem agendamento o app continua funcionando normal
        }
    }
}
