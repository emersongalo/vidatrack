package com.vidatrack.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Etapa 349 — o app (JavaScript) pega o retrato que o Android baixou sozinho. */
@CapacitorPlugin(name = "RetratoFundo")
public class RetratoFundoPlugin extends Plugin {

    @PluginMethod
    public void ler(PluginCall call) {
        getBridge().execute(() -> {
            JSObject resultado = new JSObject();
            resultado.put("json", RetratoFundo.ler(getContext()));
            call.resolve(resultado);
        });
    }

    @PluginMethod
    public void apagar(PluginCall call) {
        RetratoFundo.apagar(getContext());
        call.resolve();
    }
}
