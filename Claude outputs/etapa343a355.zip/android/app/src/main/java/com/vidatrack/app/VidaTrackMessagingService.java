package com.vidatrack.app;

import androidx.annotation.NonNull;

import com.capacitorjs.plugins.pushnotifications.MessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/**
 * Etapa 195 — recebe os pushes do Firebase no lugar do serviço padrão
 * do Capacitor. Lembrete de hábito (mensagem só de dados, tipo
 * "lembrete_habito") vira a nossa notificação com botões; todo o resto
 * segue exatamente como antes, pelo serviço do Capacitor (super).
 */
public class VidaTrackMessagingService extends MessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage mensagem) {
        Map<String, String> dados = mensagem.getData();
        if ("lembrete_habito".equals(dados.get("tipo"))) {
            LembreteHabito.mostrar(
                getApplicationContext(),
                dados.get("habitoId"),
                dados.get("titulo"),
                dados.get("corpo"),
                dados.get("data")
            );
            atualizarRetrato();
            return;
        }
        super.onMessageReceived(mensagem);
        atualizarRetrato();
    }

    /**
     * Etapa 349 — chegou notificação: aproveita que o celular está
     * acordado e atualiza os dados do app (no máximo 1x a cada 1 h).
     * Esta função já roda fora da thread principal.
     */
    private void atualizarRetrato() {
        try {
            RetratoFundo.baixarAgora(getApplicationContext(), 60L * 60 * 1000);
        } catch (Exception e) {
            // extra: nunca atrapalha a notificação
        }
    }
}
