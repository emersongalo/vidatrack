package com.vidatrack.app;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Etapa 349 — o "despertador" do Android que chama o RetratoFundo. */
public class RetratoWorker extends Worker {

    public RetratoWorker(@NonNull Context contexto, @NonNull WorkerParameters parametros) {
        super(contexto, parametros);
    }

    @NonNull
    @Override
    public Result doWork() {
        boolean ok = RetratoFundo.baixarAgora(getApplicationContext(), 30L * 60 * 1000);
        return ok ? Result.success() : Result.retry();
    }
}
