"use server";

import { revalidatePath } from "next/cache";
import { normalizarEtiquetas } from "@/lib/financas/etiquetas";
import { redirect } from "next/navigation";
import { randomUUID } from "crypto";
import { createClient } from "@/lib/supabase/server";
import { linhasTransacao, etiquetasDoFormulario, dadosTransacaoDoFormulario, type LinhasTransacao } from "@/lib/financas/linhasTransacao";
import {
  esquemaTransacao,
  esquemaConta,
  esquemaCategoria,
  primeiroErro,
} from "@/lib/validacao/financas";
import { lerLimite } from "@/lib/financas/limite";
import { camposConta, camposCategoria, idDoAparelho } from "@/lib/financas/camposCadastros";
import { dataAtualNoFuso } from "@/lib/tempo/fuso";
import { avisarMovimentacao } from "@/lib/financas/avisoMovimentacao";

/**
 * Etapa 199 — versão usada pela tela Contas: em vez de redirecionar
 * (a tela lê do retrato local e não percebia a conta nova, nem
 * mostrava o erro), devolve o resultado pra tela atualizar na hora.
 */
export async function criarContaNaTela(formData: FormData): Promise<{ erro?: string }> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { erro: "Sua sessão expirou. Entre de novo." };

  const resultado = esquemaConta.safeParse({
    nome: formData.get("nome"),
    tipo: formData.get("tipo"),
    banco: formData.get("banco"),
    saldoInicial: formData.get("saldoInicial"),
    diaFechamento: formData.get("diaFechamento"),
    diaVencimento: formData.get("diaVencimento"),
  });
  if (!resultado.success) return { erro: primeiroErro(resultado) };

  const { error } = await supabase.from("financa_contas").insert({
    dono_id: user.id,
    nome: resultado.data.nome,
    tipo: resultado.data.tipo,
    banco: resultado.data.banco,
    saldo_inicial: resultado.data.saldoInicial,
    dia_fechamento: resultado.data.diaFechamento,
    dia_vencimento: resultado.data.diaVencimento,
    // Etapa 230 — limite do cartão
    limite: resultado.data.tipo === "cartao" ? lerLimite(formData.get("limite")) : null,
  });
  if (error) return { erro: error.message };

  revalidatePath("/financas");
  return {};
}

export async function criarConta(formData: FormData) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Etapa 352 — mesma leitura do app offline + id criado no aparelho
  const r = camposConta(formData);
  if ("erro" in r) {
    redirect(`/financas/contas?erro=${encodeURIComponent(r.erro)}`);
  }
  const id = idDoAparelho(formData);

  const { error } = await supabase.from("financa_contas").insert({
    ...(id ? { id } : {}),
    dono_id: user!.id,
    ...(r as { campos: Record<string, unknown> }).campos,
  });

  if (error && !(error.code === "23505" && id)) {
    redirect(`/financas/contas?erro=${encodeURIComponent(error.message)}`);
  }

  revalidatePath("/financas");
  redirect("/financas/contas");
}

export async function arquivarConta(contaId: string) {
  "use server";
  const supabase = createClient();
  await supabase.from("financa_contas").update({ arquivado: true }).eq("id", contaId);
  revalidatePath("/financas");
  revalidatePath("/financas/contas");
}

export async function atualizarConta(contaId: string, formData: FormData) {
  const supabase = createClient();

  const r = camposConta(formData);
  if ("erro" in r) {
    redirect(`/financas/contas/${contaId}/editar?erro=${encodeURIComponent(r.erro)}`);
  }

  const { error } = await supabase
    .from("financa_contas")
    .update((r as { campos: Record<string, unknown> }).campos)
    .eq("id", contaId);

  if (error) {
    redirect(`/financas/contas/${contaId}/editar?erro=${encodeURIComponent(error.message)}`);
  }

  revalidatePath("/financas");
  revalidatePath("/financas/contas");
  redirect("/financas/contas");
}

export async function restaurarConta(contaId: string) {
  "use server";
  const supabase = createClient();
  await supabase.from("financa_contas").update({ arquivado: false }).eq("id", contaId);
  revalidatePath("/financas");
  revalidatePath("/financas/contas");
  revalidatePath("/financas/contas/lixeira");
}

export async function excluirContaDefinitivamente(contaId: string) {
  "use server";
  const supabase = createClient();
  // financa_transacoes e financa_recorrencias já têm "on delete cascade"
  // pra conta_id, então somem automaticamente junto.
  await supabase.from("compartilhamentos").delete().eq("tipo_item", "financa").eq("item_id", contaId);
  await supabase.from("financa_contas").delete().eq("id", contaId);
  revalidatePath("/financas/contas/lixeira");
}

/**
 * Versão da criação de categoria que RETORNA dados em vez de
 * redirecionar — usada pelo "+ nova categoria" dentro do formulário
 * de lançamento, pra não perder o que a pessoa já tinha preenchido lá
 * (valor, conta, data...) navegando pra outra tela.
 */
export async function criarCategoriaRapida(dados: {
  nome: string;
  tipo: "receita" | "despesa";
  icone: string;
  /** Etapa 352 — id criado no aparelho (sem internet) */
  id?: string;
}): Promise<{ id: string; nome: string; icone: string; tipo: string } | { erro: string }> {
  "use server";
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { erro: "Sessão expirada, atualiza a página." };

  const resultado = esquemaCategoria.safeParse({
    nome: dados.nome,
    tipo: dados.tipo,
    icone: dados.icone,
    cor: "financa",
  });

  if (!resultado.success) {
    return { erro: primeiroErro(resultado) };
  }

  const { data: nova, error } = await supabase
    .from("financa_categorias")
    .insert({
      ...(dados.id && RE_UUID.test(dados.id) ? { id: dados.id } : {}),
      dono_id: user.id,
      nome: resultado.data.nome,
      tipo: resultado.data.tipo,
      icone: resultado.data.icone,
      cor: resultado.data.cor,
    })
    .select("id, nome, icone, tipo")
    .single();

  if (error?.code === "23505" && dados.id) {
    return { id: dados.id, nome: resultado.data.nome, icone: resultado.data.icone, tipo: resultado.data.tipo };
  }

  if (error || !nova) {
    return { erro: error?.message ?? "Não deu pra criar a categoria." };
  }

  revalidatePath("/financas/categorias");
  return nova;
}

export async function salvarOrdemBlocosFinancas(idsEmOrdem: string[]) {
  "use server";
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  await supabase.from("perfis").update({ ordem_blocos_financas: idsEmOrdem }).eq("id", user.id);
  revalidatePath("/financas");
}

export async function criarCategoria(formData: FormData) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Etapa 352 — mesma leitura do app offline + id criado no aparelho
  const r = camposCategoria(formData);
  if ("erro" in r) {
    redirect(`/financas/categorias/nova?erro=${encodeURIComponent(r.erro)}`);
  }
  const id = idDoAparelho(formData);

  const { error } = await supabase.from("financa_categorias").insert({
    ...(id ? { id } : {}),
    dono_id: user!.id,
    ...(r as { campos: Record<string, unknown> }).campos,
  });

  if (error && !(error.code === "23505" && id)) {
    redirect(`/financas/categorias/nova?erro=${encodeURIComponent(error.message)}`);
  }

  revalidatePath("/financas/categorias");
  redirect("/financas/categorias");
}

export async function atualizarCategoria(categoriaId: string, formData: FormData) {
  const supabase = createClient();

  const r = camposCategoria(formData);
  if ("erro" in r) {
    redirect(`/financas/categorias/${categoriaId}/editar?erro=${encodeURIComponent(r.erro)}`);
  }

  const { error } = await supabase
    .from("financa_categorias")
    .update((r as { campos: Record<string, unknown> }).campos)
    .eq("id", categoriaId);

  if (error) {
    redirect(`/financas/categorias/${categoriaId}/editar?erro=${encodeURIComponent(error.message)}`);
  }

  revalidatePath("/financas/categorias");
  redirect("/financas/categorias");
}

/**
 * Etapa 352 — ajuste do envelope da categoria (acumular sobra / sobra já
 * enviada pra meta). Antes era só direto pelo Supabase do aparelho; agora
 * também dá pra fazer sem internet (a fila chama esta ação depois).
 */
export async function ajustarEnvelope(categoriaId: string, valores: Record<string, unknown>): Promise<{ erro?: string }> {
  const supabase = createClient();
  const permitidos: Record<string, unknown> = {};
  for (const k of ["envelope_desde", "sobra_enviada_mes"]) {
    if (k in (valores ?? {})) {
      const v = (valores as any)[k];
      if (v === null || (typeof v === "string" && /^\d{4}-\d{2}(-\d{2})?$/.test(v))) permitidos[k] = v;
    }
  }
  if (!Object.keys(permitidos).length) return {};
  const { data, error } = await supabase.from("financa_categorias").update(permitidos).eq("id", categoriaId).select("id");
  if (error) return { erro: error.message };
  if (!data?.length) return { erro: "Não deu pra salvar esse envelope (categoria de outra pessoa?)" };
  revalidatePath("/financas/envelopes");
  return {};
}

export async function removerCategoria(categoriaId: string) {
  "use server";
  const supabase = createClient();
  // Lançamentos que usavam essa categoria ficam sem categoria (a coluna
  // já é "on delete set null" desde a Etapa 4) — não perde o lançamento.
  await supabase.from("financa_categorias").delete().eq("id", categoriaId);
  revalidatePath("/financas/categorias");
  revalidatePath("/financas");
}

// Etapa 351 — etiquetasDoFormulario / dadosTransacaoDoFormulario moram em
// lib/financas/linhasTransacao.ts (o app usa a mesma regra sem internet).

export async function criarTransacao(formData: FormData) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // Etapa 351 — mesma montagem que o app usa offline (lib/financas/linhasTransacao)
  const montado = linhasTransacao(formData, user!.id, randomUUID);
  if ("erro" in montado) {
    redirect(`/financas/nova?erro=${encodeURIComponent(montado.erro)}`);
  }
  const { linhas, recorrencia, parcelado, resumo } = montado as LinhasTransacao;

  // Etapa 205/351 — a recorrência vem antes (o lançamento aponta pra ela)
  if (recorrencia) {
    const { error: erroRec } = await supabase.from("financa_recorrencias").insert(recorrencia);
    if (erroRec && erroRec.code !== "23505") {
      // sem a recorrência, o lançamento sai sozinho (como antes, quando ela falhava)
      delete (linhas[0] as any).recorrencia_id;
    }
  }

  // Etapa 210 — compra parcelada: uma linha por mês, a partir da data escolhida
  const { error } = await supabase.from("financa_transacoes").insert(linhas);
  if (error?.code === "23505") {
    // já tinha chegado (reenvio da fila sem internet): nada a fazer
    revalidatePath("/financas");
    redirect("/financas");
  }
  if (error) {
    // não deixa uma recorrência "solta" sem o lançamento
    if (recorrencia) await supabase.from("financa_recorrencias").delete().eq("id", recorrencia.id as string);
    redirect(`/financas/nova?erro=${encodeURIComponent(error.message)}`);
  }

  // Etapa 277 — conta compartilhada: avisa quem participa
  await avisarMovimentacao(user!.id, resumo.contaId, {
    acao: "lancou",
    tipo: resumo.tipo as any,
    valor: resumo.valor,
    descricao: resumo.descricao,
    categoriaId: resumo.categoriaId,
    data: resumo.data,
    ...(parcelado ? { parcelas: resumo.parcelas } : {}),
    hoje: dataAtualNoFuso(),
  });

  revalidatePath("/financas");
  redirect("/financas");
}

/**
 * Versão silenciosa (sem `redirect`) de criar lançamento, pra fila
 * offline (Etapa 44) — não lida com recorrência, só o lançamento
 * simples, que é o caso de uso real de "lancei algo rápido sem
 * internet".
 */
const RE_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function criarTransacaoSilenciosa(dadosFormulario: {
  tipo: string;
  valor: string;
  contaId: string;
  categoriaId: string;
  descricao: string;
  data: string;
  /** Etapa 344 — id criado no aparelho (estilo Monee): repetir o envio não duplica */
  id?: string;
  etiquetas?: string[] | null;
}): Promise<{ sucesso: boolean; erro?: string; definitivo?: boolean }> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { sucesso: false, erro: "Sessão expirada" };

  const resultado = esquemaTransacao.safeParse({
    ...dadosFormulario,
    recorrente: null,
    diaMes: null,
    dataFimRecorrencia: null,
  });

  if (!resultado.success) return { sucesso: false, erro: primeiroErro(resultado), definitivo: true };

  const idDoAparelho = dadosFormulario.id && RE_UUID.test(dadosFormulario.id) ? dadosFormulario.id : undefined;
  const etiquetas = Array.isArray(dadosFormulario.etiquetas) ? normalizarEtiquetas(dadosFormulario.etiquetas.map(String)) : [];
  const { error: erroInsert } = await supabase.from("financa_transacoes").insert({
    ...(idDoAparelho ? { id: idDoAparelho } : {}),
    dono_id: user.id,
    conta_id: resultado.data.contaId,
    categoria_id: resultado.data.categoriaId,
    tipo: resultado.data.tipo,
    valor: resultado.data.valor,
    descricao: resultado.data.descricao,
    data: resultado.data.data,
    ...(etiquetas.length ? { etiquetas } : {}),
  });
  // já tinha subido (o envio anterior chegou mas a resposta se perdeu, ou
  // foi editado no aparelho logo depois): só garante os dados mais novos
  if (erroInsert?.code === "23505" && idDoAparelho) {
    await supabase
      .from("financa_transacoes")
      .update({
        conta_id: resultado.data.contaId,
        categoria_id: resultado.data.categoriaId,
        tipo: resultado.data.tipo,
        valor: resultado.data.valor,
        descricao: resultado.data.descricao,
        data: resultado.data.data,
        ...(etiquetas.length ? { etiquetas } : {}),
      })
      .eq("id", idDoAparelho);
    return { sucesso: true };
  }
  const error = erroInsert;
  if (error && /row-level security|permission/i.test(error.message)) return { sucesso: false, erro: MSG_SEM_PERMISSAO_EDITAR, definitivo: true };

  // Etapa 277 — conta compartilhada: avisa quem participa
  if (!error) {
    await avisarMovimentacao(user.id, resultado.data.contaId, {
      acao: "lancou",
      tipo: resultado.data.tipo,
      valor: Number(resultado.data.valor),
      descricao: resultado.data.descricao,
      categoriaId: resultado.data.categoriaId,
      data: resultado.data.data,
      hoje: dataAtualNoFuso(),
    });
  }

  revalidatePath("/financas");
  return { sucesso: !error, erro: error?.message };
}

/** Etapa 344 — edição feita no aparelho chegando no servidor (lançamento simples) */
export async function atualizarTransacaoSilenciosa(
  transacaoId: string,
  dadosFormulario: { tipo: string; valor: string; contaId: string; categoriaId: string; descricao: string; data: string; etiquetas?: string[] | null }
): Promise<{ sucesso: boolean; erro?: string; definitivo?: boolean }> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { sucesso: false, erro: "Sessão expirada" };
  const resultado = esquemaTransacao.safeParse({ ...dadosFormulario, recorrente: null, diaMes: null, dataFimRecorrencia: null });
  if (!resultado.success) return { sucesso: false, erro: primeiroErro(resultado), definitivo: true };
  const d = resultado.data;
  const { data, error } = await supabase
    .from("financa_transacoes")
    .update({
      conta_id: d.contaId,
      categoria_id: d.categoriaId,
      tipo: d.tipo,
      valor: d.valor,
      descricao: d.descricao,
      data: d.data,
      ...(dadosFormulario.etiquetas !== undefined ? { etiquetas: normalizarEtiquetas((dadosFormulario.etiquetas ?? []).map(String)) } : {}),
    })
    .eq("id", transacaoId)
    .select("id");
  if (error) return { sucesso: false, erro: error.message };
  // não achou: ou foi apagado, ou a conta é "só ver" — não adianta tentar de novo
  if (!data?.length) return { sucesso: false, erro: MSG_SEM_PERMISSAO_EDITAR, definitivo: true };
  revalidatePath("/financas");
  return { sucesso: true };
}

/** Etapa 344 — exclusão feita no aparelho chegando no servidor */
export async function removerTransacaoSilenciosa(transacaoId: string): Promise<{ sucesso: boolean; erro?: string; definitivo?: boolean }> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { sucesso: false, erro: "Sessão expirada" };
  const { error } = await supabase.from("financa_transacoes").delete().eq("id", transacaoId);
  if (error) return { sucesso: false, erro: error.message };
  revalidatePath("/financas");
  return { sucesso: true };
}

const MSG_SEM_PERMISSAO_EDITAR =
  "Não deu pra salvar: essa conta foi compartilhada com você só pra ver (leitura). Quem é dono da conta pode editar, ou mudar o compartilhamento pra \"edição\".";

export async function atualizarTransacao(transacaoId: string, formData: FormData) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const resultado = esquemaTransacao.safeParse(dadosTransacaoDoFormulario(formData));

  if (!resultado.success) {
    redirect(`/financas/${transacaoId}/editar?erro=${encodeURIComponent(primeiroErro(resultado))}`);
  }
  const d = resultado.data;

  const { data: atualizadas, error } = await supabase
    .from("financa_transacoes")
    .update({
      conta_id: d.contaId,
      categoria_id: d.categoriaId,
      tipo: d.tipo,
      valor: d.valor,
      descricao: d.descricao,
      data: d.data,
      // só mexe nas etiquetas se o formulário as enviou (Etapa 218)
      ...(formData.get("etiquetasPresente") ? { etiquetas: etiquetasDoFormulario(formData) } : {}),
    })
    .eq("id", transacaoId)
    .select("id");

  if (error) {
    redirect(`/financas/${transacaoId}/editar?erro=${encodeURIComponent(error.message)}`);
  }
  // Etapa 333 — conta compartilhada só pra leitura: o banco não deixa
  // mudar e não dá erro (0 linhas). Antes parecia que salvou e nada mudava.
  if (!atualizadas || atualizadas.length === 0) {
    redirect(`/financas/${transacaoId}/editar?erro=${encodeURIComponent(MSG_SEM_PERMISSAO_EDITAR)}`);
  }

  // Etapa 210 — parcela: aplicar valor/conta/categoria às próximas
  const parcelaGrupo = String(formData.get("parcelaGrupo") ?? "");
  const parcelaNumero = Number(formData.get("parcelaNumero") ?? 0);
  if (parcelaGrupo && formData.get("aplicarParcelas") === "on") {
    await supabase
      .from("financa_transacoes")
      .update({ conta_id: d.contaId, categoria_id: d.categoriaId, tipo: d.tipo, valor: d.valor })
      .eq("parcela_grupo", parcelaGrupo)
      .gt("parcela_numero", parcelaNumero);
  }

  // Etapa 208 — lançamento que faz parte de uma recorrência
  const recorrenciaId = String(formData.get("recorrenciaId") ?? "");
  if (recorrenciaId) {
    const escopo = formData.get("escopoRecorrencia") === "so_este" ? "so_este" : "proximos";
    const parar = formData.get("pararRecorrencia") === "on";
    const mudancas: Record<string, unknown> = {};
    if (escopo === "proximos") {
      Object.assign(mudancas, {
        conta_id: d.contaId,
        categoria_id: d.categoriaId,
        tipo: d.tipo,
        valor: d.valor,
        descricao: d.descricao,
        dia_mes: Math.min(28, Number(d.data.slice(8, 10)) || 1),
      });
    }
    if (parar) mudancas.data_fim = d.data;
    if (Object.keys(mudancas).length) {
      const { error: erroRec } = await supabase.from("financa_recorrencias").update(mudancas).eq("id", recorrenciaId);
      if (erroRec) redirect(`/financas/${transacaoId}/editar?erro=${encodeURIComponent(erroRec.message)}`);
    }
    // lançamentos dessa recorrência que já existem DEPOIS deste
    if (parar) {
      await supabase.from("financa_transacoes").delete().eq("recorrencia_id", recorrenciaId).gt("data", d.data);
    } else if (escopo === "proximos") {
      await supabase
        .from("financa_transacoes")
        .update({ conta_id: d.contaId, categoria_id: d.categoriaId, tipo: d.tipo, valor: d.valor, descricao: d.descricao })
        .eq("recorrencia_id", recorrenciaId)
        .gt("data", d.data);
    }
  } else if (d.recorrente && d.diaMes) {
    // Lançamento avulso que a pessoa marcou "Repetir todo mês" ao editar
    const { data: recorrencia } = await supabase
      .from("financa_recorrencias")
      .insert({
        dono_id: user!.id,
        conta_id: d.contaId,
        categoria_id: d.categoriaId,
        tipo: d.tipo,
        valor: d.valor,
        descricao: d.descricao,
        dia_mes: d.diaMes,
        data_fim: d.dataFimRecorrencia,
        data_inicio: d.data,
      })
      .select("id")
      .single();
    if (recorrencia) {
      await supabase.from("financa_transacoes").update({ recorrencia_id: recorrencia.id }).eq("id", transacaoId);
    }
  }

  revalidatePath("/financas");
  redirect("/financas");
}

/** Etapa 210 — exclui esta parcela e as seguintes do mesmo parcelamento. */
export async function removerParcelasDaqui(transacaoId: string) {
  "use server";
  const supabase = createClient();
  const { data: t } = await supabase
    .from("financa_transacoes")
    .select("parcela_grupo, parcela_numero")
    .eq("id", transacaoId)
    .maybeSingle();
  if (!t?.parcela_grupo) {
    await supabase.from("financa_transacoes").delete().eq("id", transacaoId);
  } else {
    await supabase
      .from("financa_transacoes")
      .delete()
      .eq("parcela_grupo", t.parcela_grupo)
      .gte("parcela_numero", t.parcela_numero ?? 1);
  }
  revalidatePath("/financas");
}

/**
 * Etapa 211 — transferência entre contas (inclui pagar fatura do
 * cartão): sai de uma conta e entra na outra, as duas pontas ligadas.
 * Não conta como receita nem despesa nos totais e gráficos.
 */
export async function criarTransferencia(formData: FormData): Promise<{ erro?: string }> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { erro: "Sua sessão expirou. Entre de novo." };

  const origem = String(formData.get("contaOrigemId") ?? "");
  const destino = String(formData.get("contaDestinoId") ?? "");
  const valor = Number(String(formData.get("valor") ?? "").replace(/\./g, "").replace(",", "."));
  const data = String(formData.get("data") ?? "") || new Date().toLocaleDateString("sv-SE");
  const descricao = String(formData.get("descricao") ?? "").trim().slice(0, 200);
  if (!origem || !destino) return { erro: "Escolha as duas contas" };
  if (origem === destino) return { erro: "A conta de origem e a de destino precisam ser diferentes" };
  if (!valor || valor <= 0) return { erro: "Informe um valor válido" };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return { erro: "Data inválida" };

  const { data: contas } = await supabase.from("financa_contas").select("id, nome").in("id", [origem, destino]);
  const nome = (id: string) => contas?.find((c) => c.id === id)?.nome ?? "conta";
  // Etapa 351 — ids podem vir do aparelho (feito sem internet): reenviar não duplica
  const uuid = (k: string) => {
    const v = String(formData.get(k) ?? "");
    return RE_UUID.test(v) ? v : null;
  };
  const grupo = uuid("grupoCliente") ?? randomUUID();
  const idOrigem = uuid("idOrigemCliente");
  const idDestino = uuid("idDestinoCliente");
  const { error } = await supabase.from("financa_transacoes").insert([
    {
      ...(idOrigem && idDestino ? { id: idOrigem } : {}),
      dono_id: user.id,
      conta_id: origem,
      tipo: "despesa",
      valor,
      data,
      descricao: descricao || `Transferência para ${nome(destino)}`,
      transferencia_grupo: grupo,
    },
    {
      ...(idOrigem && idDestino ? { id: idDestino } : {}),
      dono_id: user.id,
      conta_id: destino,
      tipo: "receita",
      valor,
      data,
      descricao: descricao || `Transferência de ${nome(origem)}`,
      transferencia_grupo: grupo,
    },
  ]);
  if (error?.code === "23505" && idOrigem) return {}; // já tinha chegado
  if (error) return { erro: error.message };
  revalidatePath("/financas");
  return {};
}

export async function removerTransacao(transacaoId: string) {
  "use server";
  const supabase = createClient();
  // Etapa 211 — transferência: apagar uma ponta apaga a outra junto
  const { data: t } = await supabase
    .from("financa_transacoes")
    .select("transferencia_grupo, recorrencia_id, data")
    .eq("id", transacaoId)
    .maybeSingle();
  if (t?.transferencia_grupo) {
    await supabase.from("financa_transacoes").delete().eq("transferencia_grupo", t.transferencia_grupo);
    revalidatePath("/financas");
    return;
  }
  await supabase.from("financa_transacoes").delete().eq("id", transacaoId);

  // Etapa 262 — lançamento de uma recorrência (conta fixa) no mês atual:
  // sem isso, ao abrir Finanças de novo o app achava que "faltava" o
  // lançamento do mês e criava outro igual (parecia que apagava e voltava).
  // Agora a recorrência passa a valer a partir do mês seguinte; os
  // próximos meses continuam normais. Pra parar de vez: Recorrentes.
  if (t?.recorrencia_id && t.data) {
    const hoje = dataAtualNoFuso();
    if (String(t.data).slice(0, 7) === hoje.slice(0, 7)) {
      const [a, m] = hoje.split("-").map(Number);
      const proximoMes = `${m === 12 ? a + 1 : a}-${String(m === 12 ? 1 : m + 1).padStart(2, "0")}-01`;
      const { data: r } = await supabase.from("financa_recorrencias").select("data_inicio").eq("id", t.recorrencia_id).maybeSingle();
      if (r && (!r.data_inicio || String(r.data_inicio) < proximoMes)) {
        await supabase.from("financa_recorrencias").update({ data_inicio: proximoMes }).eq("id", t.recorrencia_id);
      }
    }
  }
  revalidatePath("/financas");
}

/**
 * Transfere dinheiro de uma conta comum pra uma conta de investimento
 * — cria uma despesa na origem (categorizada como "Investimento",
 * pra aparecer identificada no extrato) e uma receita na conta de
 * investimento, ao mesmo tempo. É assim que o dinheiro "some" do
 * saldo disponível e passa a contar no total guardado.
 */
export async function transferirParaInvestimento(formData: FormData) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const contaOrigemId = String(formData.get("contaOrigemId") ?? "");
  const contaInvestimentoId = String(formData.get("contaInvestimentoId") ?? "");
  const valor = Number(String(formData.get("valor") ?? "").replace(/\./g, "").replace(",", "."));
  const data = String(formData.get("data") ?? "") || new Date().toLocaleDateString("sv-SE");

  if (!contaOrigemId || !contaInvestimentoId || !valor || valor <= 0) {
    redirect(
      `/financas/investir?erro=${encodeURIComponent("Preencha a conta de origem, a conta de investimento e um valor válido")}`
    );
  }

  if (contaOrigemId === contaInvestimentoId) {
    redirect(`/financas/investir?erro=${encodeURIComponent("A conta de origem precisa ser diferente da de investimento")}`);
  }

  // Acha a categoria "Investimento" (criada automaticamente pra todo
  // mundo) pra já sair categorizado certo no extrato.
  const { data: categoriaInvestimento } = await supabase
    .from("financa_categorias")
    .select("id")
    .eq("dono_id", user!.id)
    .eq("nome", "Investimento")
    .eq("tipo", "despesa")
    .maybeSingle();

  const { error: erroDespesa } = await supabase.from("financa_transacoes").insert({
    dono_id: user!.id,
    conta_id: contaOrigemId,
    categoria_id: categoriaInvestimento?.id ?? null,
    tipo: "despesa",
    valor,
    descricao: "Transferência pra investimento",
    data,
  });

  if (erroDespesa) {
    redirect(`/financas/investir?erro=${encodeURIComponent(erroDespesa.message)}`);
  }

  const { error: erroReceita } = await supabase.from("financa_transacoes").insert({
    dono_id: user!.id,
    conta_id: contaInvestimentoId,
    categoria_id: null,
    tipo: "receita",
    valor,
    descricao: "Transferência recebida",
    data,
  });

  if (erroReceita) {
    // A despesa já foi criada — desfaz ela, senão o dinheiro "some"
    // sem aparecer em lugar nenhum.
    await supabase
      .from("financa_transacoes")
      .delete()
      .eq("dono_id", user!.id)
      .eq("conta_id", contaOrigemId)
      .eq("descricao", "Transferência pra investimento")
      .eq("valor", valor)
      .eq("data", data);
    redirect(`/financas/investir?erro=${encodeURIComponent(erroReceita.message)}`);
  }

  revalidatePath("/financas");
  revalidatePath("/financas/contas");
  redirect("/financas?investido=1");
}
